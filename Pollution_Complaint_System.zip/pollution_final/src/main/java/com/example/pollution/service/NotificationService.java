package com.example.pollution.service;

import com.example.pollution.entity.Notification;
import com.example.pollution.entity.PollutionReport;
import com.example.pollution.entity.User;
import com.example.pollution.repository.NotificationRepository;
import com.example.pollution.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    @Autowired private NotificationRepository notificationRepository;
    @Autowired private UserRepository userRepository;

    /**
     * Async notification — rubric: @Async / ThreadPoolTaskExecutor for real feature
     * Runs on a separate thread from the thread pool configured in AsyncConfig.
     */
    @Async("taskExecutor")
    @Transactional
    public CompletableFuture<Void> sendAlertAsync(PollutionReport report, String username) {
        try {
            log.info("🔔 [ASYNC] Sending alert on thread: {} for report ID: {}",
                    Thread.currentThread().getName(), report.getId());

            // Simulate processing delay (e.g., email sending)
            Thread.sleep(500);

            User user = userRepository.findByUsername(username).orElse(null);
            if (user == null) return CompletableFuture.completedFuture(null);

            Notification notification = new Notification();
            notification.setMessage("⚠️ " + report.getSeverity() + " level " +
                    report.getPollutionType() + " pollution reported at " +
                    report.getLocation().getCity() + ". Immediate attention required!");
            notification.setType("ALERT");
            notification.setUser(user);
            notificationRepository.save(notification);

            log.info("✅ [ASYNC] Notification saved for user: {}", username);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Async notification interrupted", e);
        }
        return CompletableFuture.completedFuture(null);
    }

    @Transactional(readOnly = true)
    public List<Notification> getUnreadForUser(String username) {
        return notificationRepository.findByUser_UsernameAndReadFalseOrderByCreatedAtDesc(username);
    }

    @Transactional
    public void markAllRead(String username) {
        List<Notification> notifications = notificationRepository.findByUser_UsernameOrderByCreatedAtDesc(username);
        notifications.forEach(n -> n.setRead(true));
        notificationRepository.saveAll(notifications);
    }
}
