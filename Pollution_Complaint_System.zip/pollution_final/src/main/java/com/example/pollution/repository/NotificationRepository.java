package com.example.pollution.repository;

import com.example.pollution.entity.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUser_UsernameAndReadFalseOrderByCreatedAtDesc(String username);
    List<Notification> findByUser_UsernameOrderByCreatedAtDesc(String username);
}
