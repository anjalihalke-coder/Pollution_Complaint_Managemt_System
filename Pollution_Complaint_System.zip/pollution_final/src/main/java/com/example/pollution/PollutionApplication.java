package com.example.pollution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync
public class PollutionApplication {
    public static void main(String[] args) {
        SpringApplication.run(PollutionApplication.class, args);
    }
}
