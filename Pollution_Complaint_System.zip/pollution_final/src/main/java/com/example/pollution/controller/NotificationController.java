package com.example.pollution.controller;

import com.example.pollution.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired private NotificationService notificationService;

    @GetMapping
    public String list(Authentication auth, Model model) {
        model.addAttribute("notifications",
                notificationService.getUnreadForUser(auth.getName()));
        return "notifications";
    }

    @PostMapping("/mark-read")
    public String markAllRead(Authentication auth) {
        notificationService.markAllRead(auth.getName());
        return "redirect:/notifications";
    }
}
