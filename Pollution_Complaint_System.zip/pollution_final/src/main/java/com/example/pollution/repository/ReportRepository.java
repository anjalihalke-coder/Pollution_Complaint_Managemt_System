package com.example.pollution.repository;

import com.example.pollution.entity.PollutionReport;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Map;

@Repository
public interface ReportRepository extends JpaRepository<PollutionReport, Long> {

    // HQL query 1 — filter by severity
    @Query("SELECT r FROM PollutionReport r WHERE r.severity = :severity ORDER BY r.reportedAt DESC")
    List<PollutionReport> findBySeverity(@Param("severity") String severity);

    // HQL query 2 — filter by pollution type
    @Query("SELECT r FROM PollutionReport r WHERE r.pollutionType = :type ORDER BY r.reportedAt DESC")
    List<PollutionReport> findByPollutionType(@Param("type") String type);

    // HQL query 3 — count per type for SDG dashboard
    @Query("SELECT r.pollutionType, COUNT(r) FROM PollutionReport r GROUP BY r.pollutionType")
    List<Object[]> countByPollutionType();

    // HQL query 4 — count per severity
    @Query("SELECT r.severity, COUNT(r) FROM PollutionReport r GROUP BY r.severity")
    List<Object[]> countBySeverity();

    // HQL query 5 — average pollution index per city (SDG metric)
    @Query("SELECT r.location.city, AVG(r.pollutionIndex) FROM PollutionReport r GROUP BY r.location.city")
    List<Object[]> avgPollutionIndexByCity();

    // Reports by logged-in user
    @Query("SELECT r FROM PollutionReport r WHERE r.submittedBy.username = :username ORDER BY r.reportedAt DESC")
    List<PollutionReport> findByUsername(@Param("username") String username);

    // All pending reports
    List<PollutionReport> findByStatusOrderByReportedAtDesc(String status);
}
