package com.example.pollution.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
@Table(name = "pollution_reports")
public class PollutionReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank
    private String pollutionType; // AIR, WATER, NOISE, SOIL, LIGHT

    @NotBlank
    @Column(length = 1000)
    private String description;

    @NotBlank
    private String severity; // LOW, MEDIUM, HIGH, CRITICAL

    private String status = "PENDING"; // PENDING, REVIEWED, RESOLVED

    private LocalDateTime reportedAt;

    private String imageUrl;

    // SDG metric field
    private Double pollutionIndex; // numeric severity index (1-10)

    // @NotNull removed — location is null at @Valid time; set manually in controller after binding
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_id")
    private Location location;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User submittedBy;

    @PrePersist
    public void prePersist() {
        if (reportedAt == null) reportedAt = LocalDateTime.now();
        if (pollutionIndex == null) {
            pollutionIndex = switch (severity.toUpperCase()) {
                case "LOW"      -> 2.5;
                case "MEDIUM"   -> 5.0;
                case "HIGH"     -> 7.5;
                case "CRITICAL" -> 10.0;
                default         -> 5.0;
            };
        }
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getPollutionType() { return pollutionType; }
    public void setPollutionType(String pollutionType) { this.pollutionType = pollutionType; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getReportedAt() { return reportedAt; }
    public void setReportedAt(LocalDateTime reportedAt) { this.reportedAt = reportedAt; }
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    public Double getPollutionIndex() { return pollutionIndex; }
    public void setPollutionIndex(Double pollutionIndex) { this.pollutionIndex = pollutionIndex; }
    public Location getLocation() { return location; }
    public void setLocation(Location location) { this.location = location; }
    public User getSubmittedBy() { return submittedBy; }
    public void setSubmittedBy(User submittedBy) { this.submittedBy = submittedBy; }
}
