package com.example.pollution.config;

import com.example.pollution.entity.*;
import com.example.pollution.repository.*;
import com.example.pollution.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired private UserRepository userRepository;
    @Autowired private RoleRepository roleRepository;
    @Autowired private LocationRepository locationRepository;
    @Autowired private UserService userService;

    @Override
    @Transactional
    public void run(String... args) {
        // Create roles if not present
        Role adminRole = roleRepository.findByName("ROLE_ADMIN")
                .orElseGet(() -> roleRepository.save(new Role("ROLE_ADMIN")));
        Role userRole = roleRepository.findByName("ROLE_USER")
                .orElseGet(() -> roleRepository.save(new Role("ROLE_USER")));

        // Create default admin
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword("admin123");
            admin.setEmail("admin@pollution.com");
            admin.setFullName("System Administrator");
            userService.registerUser(admin, Set.of(adminRole, userRole));
            log.info("✅ Default admin created: admin / admin123");
        }

        // Create default user
        if (!userRepository.existsByUsername("user1")) {
            User user = new User();
            user.setUsername("user1");
            user.setPassword("user123");
            user.setEmail("user1@pollution.com");
            user.setFullName("Test User");
            userService.registerUser(user, Set.of(userRole));
            log.info("✅ Default user created: user1 / user123");
        }

        // Seed some locations
        seedLocation("Mumbai", "Maharashtra", "400001", 19.076, 72.8777);
        seedLocation("Delhi", "Delhi", "110001", 28.6139, 77.2090);
        seedLocation("Bangalore", "Karnataka", "560001", 12.9716, 77.5946);
        seedLocation("Chennai", "Tamil Nadu", "600001", 13.0827, 80.2707);
        seedLocation("Pune", "Maharashtra", "411001", 18.5204, 73.8567);

        log.info("✅ Data initialization complete.");
    }

    private void seedLocation(String city, String state, String pincode, double lat, double lon) {
        locationRepository.findByCityAndState(city, state).orElseGet(() -> {
            Location loc = new Location();
            loc.setCity(city);
            loc.setState(state);
            loc.setPincode(pincode);
            loc.setLatitude(lat);
            loc.setLongitude(lon);
            return locationRepository.save(loc);
        });
    }
}
