package com.example.pollution.service;

import com.example.pollution.entity.Location;
import com.example.pollution.repository.LocationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class LocationService {

    @Autowired private LocationRepository locationRepository;

    public List<Location> findAll() {
        return locationRepository.findAll();
    }

    public Location save(Location location) {
        return locationRepository.save(location);
    }

    public Optional<Location> findById(Long id) {
        return locationRepository.findById(id);
    }

    public Location findOrCreate(String city, String state) {
        return locationRepository.findByCityAndState(city, state)
                .orElseGet(() -> {
                    Location loc = new Location();
                    loc.setCity(city);
                    loc.setState(state);
                    return locationRepository.save(loc);
                });
    }
}
