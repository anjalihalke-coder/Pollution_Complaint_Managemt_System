package com.example.pollution.controller;

import com.example.pollution.service.ReportService;
import com.example.pollution.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired private ReportService reportService;
    @Autowired private UserService userService;

    @GetMapping
    public String adminDashboard(Model model) {
        model.addAttribute("pendingReports", reportService.findPending());
        model.addAttribute("allUsers",       userService.findAll());
        model.addAttribute("countByType",    reportService.getCountByType());
        model.addAttribute("countBySeverity",reportService.getCountBySeverity());
        return "admin/dashboard";
    }

    @GetMapping("/users")
    public String manageUsers(Model model) {
        model.addAttribute("users", userService.findAll());
        return "admin/users";
    }

    @PostMapping("/reports/{id}/status")
    public String updateStatus(@PathVariable Long id,
                               @RequestParam String status,
                               RedirectAttributes redirectAttributes) {
        reportService.updateStatus(id, status);
        redirectAttributes.addFlashAttribute("success", "Status updated to: " + status);
        return "redirect:/admin";
    }

    @PostMapping("/users/{id}/toggle")
    public String toggleUser(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        userService.toggleEnabled(id);
        redirectAttributes.addFlashAttribute("success", "User status toggled.");
        return "redirect:/admin/users";
    }

    @PostMapping("/reports/{id}/delete")
    public String deleteReport(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        reportService.delete(id);
        redirectAttributes.addFlashAttribute("success", "Report deleted.");
        return "redirect:/admin";
    }
}
