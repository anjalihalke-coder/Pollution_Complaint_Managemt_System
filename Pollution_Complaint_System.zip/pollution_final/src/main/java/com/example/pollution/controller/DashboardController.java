package com.example.pollution.controller;

import com.example.pollution.service.NotificationService;
import com.example.pollution.service.ReportService;
import com.example.pollution.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DashboardController {

    @Autowired private ReportService reportService;
    @Autowired private UserService userService;
    @Autowired private NotificationService notificationService;

    @GetMapping("/dashboard")
    public String dashboard(Model model, Authentication auth) {
        model.addAttribute("totalReports",    reportService.getTotalCount());
        model.addAttribute("countByType",     reportService.getCountByType());
        model.addAttribute("countBySeverity", reportService.getCountBySeverity());
        model.addAttribute("avgByCity",       reportService.getAvgPollutionIndexByCity());
        model.addAttribute("recentReports",   reportService.findAll().stream().limit(5).toList());
        model.addAttribute("notifications",   notificationService.getUnreadForUser(auth.getName()));
        model.addAttribute("username",        auth.getName());
        return "dashboard";
    }
}
