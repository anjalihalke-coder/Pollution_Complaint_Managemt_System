package com.example.pollution.controller;

import com.example.pollution.entity.PollutionReport;
import com.example.pollution.service.LocationService;
import com.example.pollution.service.ReportService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/reports")
public class ReportController {

    @Autowired private ReportService reportService;
    @Autowired private LocationService locationService;

    // List all reports with optional search/filter (uses Criteria API)
    @GetMapping
    public String list(@RequestParam(required = false) String type,
                       @RequestParam(required = false) String city,
                       @RequestParam(required = false) String severity,
                       Model model) {
        if ((type != null && !type.isBlank()) ||
            (city != null && !city.isBlank()) ||
            (severity != null && !severity.isBlank())) {
            // Criteria API call — rubric requirement
            model.addAttribute("reports", reportService.searchByCriteria(type, city, severity));
            model.addAttribute("filtered", true);
        } else {
            model.addAttribute("reports", reportService.findAll());
            model.addAttribute("filtered", false);
        }
        model.addAttribute("filterType", type);
        model.addAttribute("filterCity", city);
        model.addAttribute("filterSeverity", severity);
        return "reports/list";
    }

    // Show single report
    @GetMapping("/{id}")
    public String view(@PathVariable Long id, Model model) {
        PollutionReport report = reportService.findById(id)
                .orElseThrow(() -> new RuntimeException("Report not found"));
        model.addAttribute("report", report);
        return "reports/view";
    }

    // New report form
    @GetMapping("/new")
    public String newForm(Model model) {
        model.addAttribute("report", new PollutionReport());
        model.addAttribute("locations", locationService.findAll());
        return "reports/form";
    }

    // Save report — server-side validation
    @PostMapping("/save")
    public String save(@Valid @ModelAttribute("report") PollutionReport report,
                       BindingResult result,
                       @RequestParam(required = false) Long locationId,
                       Authentication auth,
                       Model model,
                       RedirectAttributes redirectAttributes) {

        // Validate location separately since it's not bound via @ModelAttribute
        if (locationId == null) {
            result.rejectValue("location", "location.required", "Please select a location");
        }

        if (result.hasErrors()) {
            model.addAttribute("locations", locationService.findAll());
            model.addAttribute("selectedLocationId", locationId);
            return "reports/form";
        }

        // Set location from the submitted locationId
        locationService.findById(locationId).ifPresentOrElse(
            report::setLocation,
            () -> { throw new RuntimeException("Location not found: " + locationId); }
        );

        reportService.save(report, auth.getName());
        redirectAttributes.addFlashAttribute("success", "Report submitted successfully!");
        return "redirect:/reports";
    }

    // My reports
    @GetMapping("/my")
    public String myReports(Authentication auth, Model model) {
        model.addAttribute("reports", reportService.findByUsername(auth.getName()));
        return "reports/my-reports";
    }
}
