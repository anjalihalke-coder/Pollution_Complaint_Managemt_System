package com.example.pollution.repository;

import com.example.pollution.entity.Location;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface LocationRepository extends JpaRepository<Location, Long> {
    Optional<Location> findByCityAndState(String city, String state);
    List<Location> findByCity(String city);
    List<Location> findByState(String state);
}
