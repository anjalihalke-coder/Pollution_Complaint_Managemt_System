package com.example.pollution.filter;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
public class LoggingInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(LoggingInterceptor.class);

    // rubric: Servlet Interceptor for auth/logging
    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {
        String user = (request.getUserPrincipal() != null)
                ? request.getUserPrincipal().getName()
                : "anonymous";
        log.info("➡️  [REQUEST]  {} {} | User: {} | Session: {}",
                request.getMethod(),
                request.getRequestURI(),
                user,
                request.getSession().getId().substring(0, 8));
        request.setAttribute("startTime", System.currentTimeMillis());
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request,
                           HttpServletResponse response,
                           Object handler,
                           ModelAndView modelAndView) {
        if (modelAndView != null) {
            log.debug("📄 [VIEW]     Rendering: {}", modelAndView.getViewName());
        }
    }

    @Override
    public void afterCompletion(HttpServletRequest request,
                                HttpServletResponse response,
                                Object handler,
                                Exception ex) {
        long startTime = (long) request.getAttribute("startTime");
        long duration = System.currentTimeMillis() - startTime;
        log.info("⬅️  [RESPONSE] {} | Status: {} | Time: {}ms",
                request.getRequestURI(), response.getStatus(), duration);
        if (ex != null) {
            log.error("❌ [ERROR]    Exception during request: {}", ex.getMessage());
        }
    }
}
