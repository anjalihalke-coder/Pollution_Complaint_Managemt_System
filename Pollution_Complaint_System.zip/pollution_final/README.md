# 🌍 Pollution Monitoring System
### Spring Boot + Hibernate + Spring Security | SDG 11 & SDG 3

---

## 🚀 Quick Setup (5 minutes)

### 1. Prerequisites
- Java 17+
- Maven 3.8+
- MySQL 8.x running locally

### 2. Create Database
```sql
CREATE DATABASE pollution_db;
```

### 3. Configure DB credentials
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=YOUR_PASSWORD
```

### 4. Run the project
```bash
cd pollution
mvn spring-boot:run
```

### 5. Open in browser
```
http://localhost:8080
```

---

## 🔐 Default Login Credentials

| Username | Password  | Role        |
|----------|-----------|-------------|
| admin    | admin123  | ADMIN + USER |
| user1    | user123   | USER        |

---

## 📋 Rubric Coverage

### ✅ Requirement & Design (3 pts)
- 5+ Hibernate entities with `@Entity`, `@Id`
- `@OneToMany` (User → Reports, Location → Reports)
- `@ManyToMany` (User ↔ Role) with cascade
- 6 DB tables: users, roles, user_roles, locations, pollution_reports, notifications
- FK constraints via JPA relationships

### ✅ Back-end Development (3 pts)
- Full `@Controller` → `@Service` → `@Repository` layered architecture
- HQL queries in `ReportRepository` (5 custom `@Query` methods)
- **Criteria API** in `ReportService.searchByCriteria()` (used by the filter/search feature)
- `@Transactional` on all service methods with `rollbackFor` on status update
- JDBC `PreparedStatement` batch insert in `ReportService.batchInsertReportsRaw()`
- Exception handling throughout all layers

### ✅ Front-end / Web Layer (3 pts)
- 7 Thymeleaf pages: login, register, dashboard, reports/list, reports/form, reports/view, reports/my-reports, admin/dashboard, admin/users, notifications
- Client-side JS validation + server-side `@Valid` + `BindingResult`
- `LoggingInterceptor` implements `HandlerInterceptor` for auth/logging
- Role-based access: `ROLE_ADMIN` and `ROLE_USER` via Spring Security
- Session management via Spring Security + cookie invalidation on logout
- Clean MVC endpoint mapping

### ✅ Multithreading (2 pts)
- `ThreadPoolTaskExecutor` configured in `AsyncConfig` (core=3, max=10, queue=100)
- `@Async("taskExecutor")` on `NotificationService.sendAlertAsync()`
- Triggered automatically for HIGH/CRITICAL severity reports
- Thread name visible in logs: `PollutionAsync-1`, `PollutionAsync-2`, etc.

### ✅ SDG Integration (1+1 pts)
- **SDG 11** (Sustainable Cities) + **SDG 3** (Good Health)
- Dashboard shows: total reports, count by type, count by severity, avg pollution index by city
- Avg pollution index is DB-driven and updates live
- Written justification (≤200 words) displayed on dashboard
- Cities classified as LOW RISK / MODERATE / HIGH RISK based on index

---

## 🗂️ Project Structure

```
src/main/java/com/example/pollution/
├── PollutionApplication.java       ← @SpringBootApplication + @EnableAsync
├── entity/                         ← Hibernate @Entity classes
│   ├── User.java                   ← @ManyToMany roles, @OneToMany reports
│   ├── Role.java
│   ├── Location.java
│   ├── PollutionReport.java        ← @ManyToOne location+user, @PrePersist
│   └── Notification.java
├── repository/                     ← Spring Data JPA @Repository
│   ├── UserRepository.java
│   ├── ReportRepository.java       ← HQL @Query methods
│   ├── LocationRepository.java
│   ├── RoleRepository.java
│   └── NotificationRepository.java
├── service/                        ← @Service @Transactional
│   ├── ReportService.java          ← Criteria API + JDBC PreparedStatement
│   ├── UserService.java            ← UserDetailsService for Spring Security
│   ├── LocationService.java
│   └── NotificationService.java   ← @Async thread pool
├── controller/                     ← @Controller MVC
│   ├── HomeController.java
│   ├── DashboardController.java
│   ├── ReportController.java
│   ├── AdminController.java
│   ├── RegisterController.java
│   └── NotificationController.java
├── config/
│   ├── SecurityConfig.java         ← Spring Security, 2 roles, session
│   ├── AsyncConfig.java            ← ThreadPoolTaskExecutor
│   ├── WebMvcConfig.java           ← Registers LoggingInterceptor
│   └── DataInitializer.java        ← Seeds roles, admin, locations
└── filter/
    └── LoggingInterceptor.java     ← HandlerInterceptor for logging
```
